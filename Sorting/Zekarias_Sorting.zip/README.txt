to start run make
sorted and unsorted arrays should both run
to clean run make clean